# TITLE: Stock Price Performance of Pharmaceutical Companies during COVID-19 in the US

# Overview
The project aims to analyze the relationship between the stock price performance of 
major pharmaceutical companies and the impact of COVID-19 on the U.S. population 
during the pandemic. Specifically, it seeks to determine if there is a correlation 
between fluctuations in U.S. COVID-19 death rates and the stock prices of pharmaceutical 
companies that played were involved in the development and distribution of vaccines in the pandemic. 
This analysis will focus on the period from 2020 to 2021, capturing the timeline when to the pandemic was at its absolute peak.

Stock Price Performance:
The companies under review include but are notlimited to - Pfizer, Moderna, AstraZeneca, and Johnson & Johnson, all of which were deeply involved in COVID-19 vaccine development. The stock price 
data for these companies will be collected using the Alpha Vantage API, which provides 
historical stock price data for detailed analysis. Weekly or monthly stock prices from 
2020 to 2021 will be analyzed to capture significant trends, like at the time of vaccine approvals, the onset of COVID-19 waves, and government announcements that played a part in the evolution of the pandemic.

COVID-19 Impact on the U.S. Population:
The project will use the COVID-19 dataset provided by Johns Hopkins University,
which includes detailed statistics on daily and weekly death counts across different
U.S. regions. This data will be integrated with stock price performance to explore 
whether fluctuations in the number of deaths influenced market perceptions and 
stock prices. Data will be aggregated at both the national level and by specific 
regions in the U.S. that were more heavily affected by the pandemic - like regions of high populations (The U.S. coast), allowing for an analysis of localized and overall impacts.

Data Integration and Cleaning:
The integration of stock price and COVID-19 death data will be handled programmatically 
using Python and SQL. Data profiling and quality assessment will be performed using 
tools like OpenRefine to ensure transparency, reproducibility and replicability. Cleaning the data 
for inconsistencies, missing values, and ensuring the accuracy of both datasets is 
critical for the integrity of the analysis.

Statistical Analysis:
Correlation analysis will be used to determine whether changes in COVID-19 death 
rates have a statistically significant relationship with the stock prices of the pharmaceutical 
companies. Irith Chaturvedi and Thomas Jiang will contribute to the statistical analysis using Python's Pandas library. 
Key events like vaccine approvals and government curfues on the freedom of movement will be highlighted 
to observe their impact on stock performance.

# research question
How did fluctuations in US COVID-19 death/case rates correlate with changes in the stock prices 
of major pharmaceutical companies during the COVID-19 pandemic?

# Team

Irith Chaturvedi - irithc2: While assisting in the Statistical analysis of the project, he is also responsible for finding the appropriate dataset on COVID 19 
statitics on number of cases and deaths within the United States. He will also carry out 
data integration, profiling and cleaning using OpenRefine and SQL.

Thomas Jiang - tianqij3: Is credited with finding the datasets and acquiring the API key 
to collect information on the updated stock prices on the Alpha Advantage API website. 
He will also conduct correlation and statitical analyses on the trends of stock 
prices and cases/deaths in the Covid 19 dataset using Python/Pandas.
 
# Datasets

Stock Price Data:

Alpha Vantage API: Contains historical stock prices for major pharmaceutical companies 
like Pfizer, Moderna, AstraZeneca, Johnson & Johnson, etc., for the period during COVID-19.
https://www.alphavantage.co/documentation/

COVID-19 Data:

Johns Hopkins University COVID-19 Data: This dataset includes global COVID-19 death counts, 
available by country and over time. (We will focus only on the U.S. for our project.)
https://github.com/CSSEGISandData/COVID-19



# Timeline (Estimated)

Defining Research Question (10/16/2024) – Irith and Thomas:
This step involved clearly formulating the central question our project: how the stock price performance of pharmaceutical companies during COVID-19 correlates with U.S. COVID-19 death rates. This helped in setting the project’s focus and guides the data analysis.

Data Collection (10/18/2024) – Irith and Thomas:
In this stage, we gathered the necessary datasets. Thomas focused on acquiring historical stock prices of pharmaceutical companies via the Alpha Vantage API, while Irith found accurate COVID-19 cases and deaths data for the U.S. using the Johns Hopkins COVID-19 dataset.

Automatic (Programmatic) Integration of Datasets (10/24/2024) – Irith:
Using Python/Pandas and/or SQL, Irith integrated the stock price and COVID-19 datasets. This involved aligning the data by dates and making sure that they can be analyzed together for adequate integration of the sources.

Transparent Data Profiling, Quality Assessment, and Cleaning (10/24/2024) – Irith:
Here, Irith used tools like OpenRefine and SQL to assess the quality of the data. This included identifying missing or inaccurate data points, removing duplicates, and ensuring all records are properly formatted. The goal was to make the dataset clean and usable for analysis.

Implement Simple Data Analysis and/or Visualization (10/24/2024) – Thomas:
Thomas began with initial analyses, such as calculating the percentage change in stock prices and identifying trends in COVID-19 death rates. He may also create basic visualizations like time-series graphs to show how these two datasets behave over time.

Create a Reproducible Package (10/31/2024) – Irith or Thomas, TBD:
This step involves creating a package (likely in Python or R) that allows others to reproduce the analysis. It will include the scripts used for data cleaning, analysis, and visualization, ensuring the results are easily replicable.

Automated End-to-End Workflow Execution (11/10/2024) – Irith or Thomas, TBD:
The team will automate the entire process, from data collection to analysis and visualization. This ensures that the workflow can run seamlessly from start to finish without manual intervention, allowing also for dynamic updates if new data is introduced.

Accurate Citation of Data and Software Used (11/10/2024) – Thomas:
Thomas will compile accurate citations for all datasets and tools used throughout the project. Proper attribution is critical for academic integrity and for ensuring that others can access and use the same data we used for our project.

Create Metadata Describing Your Package (12/1/2024) – Irith:
Irith will create metadata that describes the contents, structure, and functionality of the package. This metadata will help users understand how to use the package, what data it contains, etc.

Archive Your Project in a Repository, Obtaining a Persistent Identifier (12/5/2024) – Irith or Thomas, TBD:
The project will be archived probably using GitHub, a resource we have been using throughout the semester to record our Labs and assignments - to ensure it’s accessible for future use.