import pandas as pd
import matplotlib.pyplot as plt


# Read the data
data = pd.read_csv('Combined_weekly_filtered.csv')

output_folder = 'Stocks_Graphs'
data['Date'] = pd.to_datetime(data['Date'])

# Plot the high values for each stock
plt.figure(figsize=(10, 6))
for stock, group in data.groupby("Stock"):
    plt.plot(group['Date'], group['2. high'], label=stock)

# Customize the plot
plt.title("High Values for Stocks Over Time")
plt.xlabel("Date")
plt.ylabel("High Value")
plt.legend(title="Stock")
plt.grid(True)
plt.tight_layout()
plt.legend()
plt.savefig("Stocks_Graphs/Weekly_high_per_company.png")
plt.close()

plt.figure(figsize=(10, 6))
for stock, group in data.groupby("Stock"):
    plt.plot(group['Date'], group['6. volume'], label=stock)

# Customize the plot
plt.title("Volume of Stocks Over Time")
plt.xlabel("Date")
plt.ylabel("Volume")
plt.legend(title="Stock")
plt.grid(True)
plt.tight_layout()
plt.legend()
plt.savefig("Stocks_Graphs/Weekly_volume_per_company.png")
plt.close()