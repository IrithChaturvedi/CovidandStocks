import pandas as pd
import matplotlib.pyplot as plt

# Read the data
data_covid = pd.read_csv('combined_covid_data.csv')

# Aggregate data by date
data_covid['Last_Update'] = pd.to_datetime(data_covid['Last_Update'], errors='coerce')
selected_dates = ['2021-01-06', '2021-01-08', '2021-01-12', '2021-01-13']
filtered_data = data_covid[data_covid['Last_Update'].isin(pd.to_datetime(selected_dates))]
# Filter numeric columns for aggregation
numeric_cols = filtered_data.select_dtypes(include=['number']).columns

data_by_date = filtered_data.groupby('Last_Update')[numeric_cols].sum().reset_index()

# First graph: Confirmed cases by date
plt.figure(figsize=(10, 6))
plt.plot(data_by_date['Last_Update'], data_by_date['Confirmed'], color='blue', label='Confirmed')
plt.scatter(data_by_date['Last_Update'], data_by_date['Confirmed'], color='red', label='Confirmed')
plt.title('Confirmed Cases by Date')
plt.xlabel('Last Update')
plt.ylabel('Number of Cases')
plt.xticks(rotation=45)
plt.tight_layout()
plt.legend()
plt.savefig("Covid_Graphs/confirmed_cases_by_date.png")
plt.close()

# Second graph: Deaths by date
plt.figure(figsize=(10, 6))
plt.plot(data_by_date['Last_Update'], data_by_date['Deaths'], color='red', label='Deaths')
plt.scatter(data_by_date['Last_Update'], data_by_date['Deaths'], color='red', label='Deaths')
plt.title('Deaths by Date')
plt.xlabel('Last Update')
plt.ylabel('Number of Deaths')
plt.xticks(rotation=45)
plt.tight_layout()
plt.legend()
plt.savefig("Covid_Graphs/deaths_by_date.png")
plt.close()

# Aggregate data by state (mean)
data_by_state_mean = data_covid.groupby('Province_State').agg('mean').reset_index()

# Third graph: Incident Rate by state
plt.figure(figsize=(10, 6))
plt.bar(data_by_state_mean['Province_State'], data_by_state_mean['Incident_Rate'], color='green', label='Incident Rate')
plt.title('Incident Rate by State')
plt.xlabel('Province/State')
plt.ylabel('Incident Rate')
plt.xticks(rotation=90)
plt.tight_layout()
plt.legend()
plt.savefig("Covid_Graphs/incident_rate_by_state.png")
plt.close()

# Fourth graph: Case Fatality Ratio by state
plt.figure(figsize=(10, 6))
plt.bar(data_by_state_mean['Province_State'], data_by_state_mean['Case_Fatality_Ratio'], color='orange', label='Case Fatality Ratio')
plt.title('Case Fatality Ratio by State')
plt.xlabel('Province/State')
plt.ylabel('Case Fatality Ratio')
plt.xticks(rotation=90)
plt.tight_layout()
plt.legend()
plt.savefig("Covid_Graphs/case_fatality_ratio_by_state.png")
plt.close()


