import os
import requests
import pandas as pd

# Ensure directories exist
os.makedirs('Data', exist_ok=True)
os.makedirs('Data_Stocks', exist_ok=True)

def fetch_and_save_stock_data(symbol, api_key, output_path):
    api_url = f'https://www.alphavantage.co/query?function=TIME_SERIES_WEEKLY_ADJUSTED&symbol={symbol}&apikey={api_key}'
    response = requests.get(api_url)
    data = response.json()

    if "Weekly Adjusted Time Series" in data:
        weekly_data = data["Weekly Adjusted Time Series"]
        df = pd.DataFrame.from_dict(weekly_data, orient='index')
        df.index.name = 'Date'
        df = df.reset_index()
        df.to_csv(output_path, index=False)
        print(f"Data saved to {output_path}")
        return True
    else:
        print(f"Data not available or API response issue for {symbol}.")
        return False

def filter_by_key_dates(input_path, output_path, key_dates):
    try:
        data = pd.read_csv(input_path)
        data.columns = data.columns.str.strip()
        data['Date'] = pd.to_datetime(data['Date'], errors='coerce')

        if data['Date'].isna().any():
            print(f"Error: Some dates could not be parsed in {input_path}.")
            return

        # Generate weekly range
        date_ranges = [
            (date - pd.Timedelta(days=date.weekday()),
             date - pd.Timedelta(days=date.weekday()) + pd.Timedelta(days=6))
            for date in key_dates
        ]

        # Filter data within the date ranges
        filtered_data = data[data['Date'].apply(
            lambda x: any(start <= x <= end for start, end in date_ranges)
        )]

        filtered_data.to_csv(output_path, index=False)
        print(f"Filtered data saved to {output_path}")
    except Exception as e:
        print(f"Error processing file {input_path}: {e}")

# Main script
api_key = 'VRN9E0F08NBINEZ4'
symbols = ['JNJ', 'PFE', 'AZN']
key_dates = pd.to_datetime([
    "2019-12-12", "2020-01-20", "2020-03-19",
    "2020-12-11", "2020-12-18", "2021-01-06",
    "2021-01-08", "2021-01-12", "2021-01-13",
])

for symbol in symbols:
    raw_output_path = f'Data/{symbol}_weekly_adjusted.csv'
    filtered_output_path = f'Data_Stocks/{symbol}_weekly_filtered.csv'

    if fetch_and_save_stock_data(symbol, api_key, raw_output_path):
        filter_by_key_dates(raw_output_path, filtered_output_path, key_dates)


