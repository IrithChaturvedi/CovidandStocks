import pandas as pd  
import os  
import datetime  

# Cleans and aggregates COVID-19 data for the US from a given file
def clean_usa_data(file_path):
    # Read the CSV file into a DataFrame
    df = pd.read_csv(file_path)
    
    # Filter for rows where the country is the US
    usa_df = df[df["Country_Region"] == "US"]
    
    # Group data by province/state and aggregate relevant columns
    grouped_usa_df = usa_df.groupby("Province_State").agg({
        "Confirmed": "sum",
        "Deaths": "sum",
        "Recovered": "sum",
        "Active": "sum",
        "Incident_Rate": "mean",
        "Case_Fatality_Ratio": "mean",
        "Last_Update": "first"  # Retain the first occurrence for Last_Update
    }).reset_index()
    
    # Parse the 'Last_Update' column to datetime and extract the date only
    grouped_usa_df['Last_Update'] = pd.to_datetime(grouped_usa_df['Last_Update'], errors='coerce').dt.date
    
    # Subtract one day to adjust the date
    grouped_usa_df['Last_Update'] = grouped_usa_df['Last_Update'] - datetime.timedelta(days=1)
    
    return grouped_usa_df


# Processes multiple CSV files and saves cleaned versions
def process_multiple_csvs(file_paths):
    for file_path in file_paths:
        cleaned_data = clean_usa_data(file_path)
        base_name = os.path.basename(file_path)  # Extract filename
        output_name = f"Cleaned/{os.path.splitext(base_name)[0]}_cleaned.csv"
        cleaned_data.to_csv(output_name, index=False)  # Save cleaned data

# List of input files to process
csv_files = [
    'CasesData/01-06-2021.csv',
    'CasesData/01-08-2021.csv',
    'CasesData/01-12-2021.csv',
    'CasesData/01-13-2021.csv',
    'CasesData/12-11-2020.csv'
]

# Run processing
process_multiple_csvs(csv_files)


