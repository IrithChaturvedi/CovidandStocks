import pandas as pd  # For data manipulation

# Load cleaned data from CSV files into DataFrames
six_jan = pd.read_csv('Cleaned/01-06-2021_cleaned.csv')
eight_jan = pd.read_csv('Cleaned/01-08-2021_cleaned.csv')
twelve_jan = pd.read_csv('Cleaned/01-12-2021_cleaned.csv')
thirteen_jan = pd.read_csv('Cleaned/01-13-2021_cleaned.csv')
eleven_dec = pd.read_csv('Cleaned/12-11-2020_cleaned.csv')

# Combine all DataFrames into one, ignoring the index for a unified dataset
combined_data = pd.concat([six_jan, eight_jan, twelve_jan, thirteen_jan, eleven_dec], ignore_index=True)

# Save the combined data to a new CSV file
combined_output_path = 'combined_covid_data.csv'
combined_data.to_csv(combined_output_path, index=False)  # Save without row indices
