import pandas as pd

azn_filtered = pd.read_csv('Data_Stocks/AZN_weekly_filtered.csv')
jnj_filtered = pd.read_csv('Data_Stocks/JNJ_weekly_filtered.csv')
pfe_filtered = pd.read_csv('Data_Stocks/PFE_weekly_filtered.csv')

# Add a column to distinguish datasets
azn_filtered['Stock'] = 'AZN'
jnj_filtered['Stock'] = 'JNJ'
pfe_filtered['Stock'] = 'PFE'

# Standardize column names for merging
azn_filtered.columns = azn_filtered.columns.str.strip()
jnj_filtered.columns = jnj_filtered.columns.str.strip()
pfe_filtered.columns = pfe_filtered.columns.str.strip()

# Concatenate all datasets
combined_data = pd.concat([azn_filtered, jnj_filtered, pfe_filtered], ignore_index=True)

# Save the combined dataset to a new CSV file
combined_output_path = 'Combined_weekly_filtered.csv'
combined_data.to_csv(combined_output_path, index=False)