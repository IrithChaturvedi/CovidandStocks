# Project Status Report: Stock Price Performance of Pharmaceutical Companies during COVID-19 in the US

## Project Overview
The goal of this project is to analyze the relationship between COVID-19 death and case rates and stock price performance of major pharmaceutical companies that were involved in vaccine production. This analysis aims to provide insights valuable to stakeholders, including investors and public health officials while being informative for the general audience. Focusing on 10 significant dates within the COVID-19 pandemic timeline, we aim to understand any correlations in the stock market response of 3 major pharmaceutical companies to fluctuations in the COVID-19 impact within the U.S.

---

## Current Task Updates

### Data Collection
**Status:** Complete  
**Artifacts:** CSV files retrieved from sources below:

- **COVID-19 Data:** We successfully retrieved COVID-19 daily case and death counts on the 10 most significant days related to the COVID-19 pandemic from the Johns Hopkins University GitHub repository.  
  **10 most significant dates related to the COVID-19 pandemic were chosen based on their relevance to major events and impacts on public health and market conditions:**

  - **December 12, 2019:** A cluster of patients in Wuhan, China, began experiencing symptoms of an atypical pneumonia-like illness, marking the initial known cases of COVID-19.
  - **January 20, 2020:** The first confirmed U.S. case of COVID-19 was reported in Washington state.
  - **March 19, 2020:** California issued the first statewide stay-at-home order in the U.S. to curb the spread of the virus.
  - **January 8, 2021:** The U.S. reported its highest single-day number of new COVID-19 cases, with over 300,000 new infections.
  - **January 12, 2021:** The U.S. recorded its second-highest single-day number of new cases, with approximately 250,000 new infections.
  - **January 6, 2021:** The U.S. reported its third-highest single-day number of new cases, with around 240,000 new infections.
  - **January 12, 2021:** The U.S. experienced its highest single-day death toll from COVID-19, with over 4,400 deaths.
  - **January 13, 2021:** The U.S. recorded its second-highest single-day death toll, with more than 4,300 deaths.
  - **December 11, 2020:** The U.S. Food and Drug Administration (FDA) granted Emergency Use Authorization (EUA) for the Pfizer-BioNTech COVID-19 vaccine, the first COVID-19 vaccine approved in the U.S.
  - **December 18, 2020:** The FDA issued an EUA for the Moderna COVID-19 vaccine, the second vaccine approved in the U.S.

- **Stock Price Data:** We acquired historical stock prices of AstraZeneca, Johnson & Johnson, and Pfizer using the Alpha Vantage API, covering the weeks common to our 10 most significant dates on the COVID-19 timeline.

**Notes:** All datasets have been imported and stored in our project repository for subsequent tasks.

---

### Data Profiling, Quality Assessment, and Cleaning
**Status:** Complete  
**Artifacts:**
- Python scripts for handling missing values and cleaning datasets for stocks (`DataAcquisitionCleaning.py`, `DataintegrationStocks.py`). These scripts handled tasks such as imputing missing data, ensuring consistent date formatting, and standardizing stock price records.
- Python scripts for handling missing values and cleaning datasets for COVID data (`data_cleaning_covid.py`). For the COVID-19 dataset, data was filtered to include information pertaining to U.S. states. Results were aggregated for fields like Confirmed Cases, Deaths, Incident Rate, and Case Fatality Ratio using functions within the Pandas library.

**Notes:**
- Data profiling identified minor discrepancies in dates and some missing stock prices. These issues were corrected using Python to ensure dataset integrity. Python replaced tools like OpenRefine and SQL for this task, streamlining the cleaning process while achieving the same outcomes.


---

### Data Integration
**Status:** In Progress  
**Artifacts:**
- **Integrated Stock Price File:** `Combined_weekly_filtered.csv`, merging stock price data for AstraZeneca, Johnson & Johnson, and Pfizer into a single dataset for our chosen dates.

**Notes:** The integration was handled with Python, ensuring that dates align accurately to allow precise correlation analysis. We are working on integrating the COVID-19 datasets and the stock price datasets based on the common dates shared by the sources.

---

### Data Visualization
**Status:** In Progress  
**Artifacts:**
- Visualizations of trends in COVID-19 death rates and corresponding stock price movements across significant dates.
- Time-series charts and correlation plots to be created in Python to show the relation between the number of cases, deaths, and changes in stock prices of pharmaceutical companies per day.

**Notes:** Visualizations indicate initial trends and suggest moderate to strong correlations between major COVID-19 events and stock price fluctuations, particularly during key vaccine approval dates. For example, there is a notable increase in stock prices of Pfizer and Moderna around the vaccine EUA dates (December 2020), which aligns with heightened market optimism.

---

### Automated End-to-End Workflow Execution
**Status:** In Progress  
**Artifacts:**
- **Workflow Automation Script:** `Snakefile`.
- **Workflow Automation Diagram:** `workflow.png`.

**Notes:** Initial workflow automation script for data collection, cleaning, and integration has been created by writing separate rules for each process. Automation of further integration and visualization processes is underway to allow for dynamic data refreshes if new data becomes available.

---

### Citation and Documentation
**Status:** Not Started  
**Planned Completion:** December 1, 2024  
**Notes:** Accurate citations for all datasets and software used will be compiled, with documentation including examples and tutorials to guide replication and interpretation.

---

### Metadata Creation and Archival
**Status:** Upcoming  
**Planned Completion:** December 1, 2024  
**Notes:** A metadata file will be created to describe the structure and functionality of the final project package.

---

## Updated Timeline
- All tasks are progressing as per the initial schedule.
- Automated workflow, Data Visualization, and citation tasks are currently on track for completion by the end of November.
- Final tasks, including metadata creation and project archiving, remain scheduled for completion by early December.

---

## Project Plan Adjustments
No major changes to the project plan are required at this time, as all tasks are proceeding according to the original schedule. The minor changes include choosing specific days to conduct our analysis on and limiting our analysis to only 3 companies and their stock price data.